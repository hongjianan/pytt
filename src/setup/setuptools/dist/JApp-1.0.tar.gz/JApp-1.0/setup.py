# -*- coding: utf-8 -*-
'''
Created on 2018年5月1日

@author: Hong
'''

from setuptools import setup

setup(
	name='JApp',
	version='1.0',
	author='jason',
	author_email='hjnhong@163.com',
	package=['japp']
)

if __name__ == '__main__':
	pass